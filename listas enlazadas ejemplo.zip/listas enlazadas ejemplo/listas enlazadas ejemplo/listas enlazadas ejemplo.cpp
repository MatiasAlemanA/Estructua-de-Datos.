// listas enlazadas ejemplo.cpp : Defines the entry point for the console application.

//[ insertar un elemento en una lista]

#include "stdafx.h"
#include "conio.h"
#include <iostream>

using namespace std;


struct Nodo{
int dato; // Ingresamos el dato
Nodo *siguiente; //puntero para determinar el siguiente
};



//Prototipo de la funcion
void insertarLista(Nodo *&, int ); // 2 parametro 



int main(){
	Nodo *Lista=NULL; // crear puntero lista e igual a NULL
	int dato;

	cout<<"Digite un numero : ";
	cin>>dato;
	insertarLista(Lista, dato);

	getch();
	return 0;
}


void insertarLista(Nodo *&Lista, int n){
	 Nodo*nuevo_nodo= new Nodo();     //crear un espacio en memoria (creando un nodo)
	 nuevo_nodo -> dato = n;         // Asignar dato al nuevo nodo


	 // Creamos dos punteros 
	 Nodo*aux1 = Lista;
	 Nodo*aux2;

	 while((aux1 != NULL) && (aux1-> dato<n)){       // Ordenar nuestra lista
	 
	 aux2 = aux1;
	 aux1= aux1-> siguiente;
	 }

	 if(Lista == aux1){          // saber ubicacacion, saber si va al principio
	 Lista= nuevo_nodo;
	 }
	 else{ aux2->siguiente = nuevo_nodo;    //(entro a while) y recorre una posicion
	 }
	 nuevo_nodo ->siguiente= aux1;	
	 cout<<"\t  Elemento "<<n<<" Insertado a lista correctamente  "<<endl; 
}