#include "StdAfx.h"
#include "Pila.h"


Pila::Pila(void)
{
	iniciar();
}


Pila::~Pila(void)
{
}

void Pila::iniciar(){
tope=-1;
}

int Pila::gettope(){
return tope;
}

bool Pila::pilallena(){
	if(gettope()==MAX-1){return true;
	}else{ return false;
	     }
}

bool Pila::pilavacia(){
	if(gettope()==-1){ return true;
	}else{ return false;
	     }
}
bool Pila::apilar(int dato){
	if(pilallena()){return false;
	}else{
		 tope=gettope()+1;
		 PILA[tope]=dato;
		 return true;
	     }
}

int Pila::valortope(){
    return PILA[gettope()];
}

int Pila::mostrarvalor(int i){

return PILA[i];
} 