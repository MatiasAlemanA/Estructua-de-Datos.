#pragma once

#include "Pila.h"

Pila pila1;
int pos=0;
 int aux=0;

namespace PPilas1 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  lblValor;
	protected: 
	private: System::Windows::Forms::TextBox^  txtValor;
	private: System::Windows::Forms::Button^  btnApilar;
	private: System::Windows::Forms::DataGridView^  dataGridView1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Pila1;
	private: System::Windows::Forms::Label^  lblNElementos;
	private: System::Windows::Forms::TextBox^  txtNElementos;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->lblValor = (gcnew System::Windows::Forms::Label());
			this->txtValor = (gcnew System::Windows::Forms::TextBox());
			this->btnApilar = (gcnew System::Windows::Forms::Button());
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->Pila1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->lblNElementos = (gcnew System::Windows::Forms::Label());
			this->txtNElementos = (gcnew System::Windows::Forms::TextBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView1))->BeginInit();
			this->SuspendLayout();
			// 
			// lblValor
			// 
			this->lblValor->AutoSize = true;
			this->lblValor->Location = System::Drawing::Point(48, 54);
			this->lblValor->Name = L"lblValor";
			this->lblValor->Size = System::Drawing::Size(46, 20);
			this->lblValor->TabIndex = 0;
			this->lblValor->Text = L"Valor";
			// 
			// txtValor
			// 
			this->txtValor->Location = System::Drawing::Point(149, 54);
			this->txtValor->Name = L"txtValor";
			this->txtValor->Size = System::Drawing::Size(100, 26);
			this->txtValor->TabIndex = 1;
			// 
			// btnApilar
			// 
			this->btnApilar->Location = System::Drawing::Point(201, 118);
			this->btnApilar->Name = L"btnApilar";
			this->btnApilar->Size = System::Drawing::Size(90, 45);
			this->btnApilar->TabIndex = 2;
			this->btnApilar->Text = L"Apilar";
			this->btnApilar->UseVisualStyleBackColor = true;
			this->btnApilar->Click += gcnew System::EventHandler(this, &Form1::btnApilar_Click);
			// 
			// dataGridView1
			// 
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Pila1});
			this->dataGridView1->Location = System::Drawing::Point(39, 105);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->RowTemplate->Height = 28;
			this->dataGridView1->Size = System::Drawing::Size(137, 160);
			this->dataGridView1->TabIndex = 3;
			// 
			// Pila1
			// 
			this->Pila1->HeaderText = L"Pila1";
			this->Pila1->Name = L"Pila1";
			// 
			// lblNElementos
			// 
			this->lblNElementos->AutoSize = true;
			this->lblNElementos->Location = System::Drawing::Point(362, 140);
			this->lblNElementos->Name = L"lblNElementos";
			this->lblNElementos->Size = System::Drawing::Size(100, 20);
			this->lblNElementos->TabIndex = 4;
			this->lblNElementos->Text = L"N.Elementos";
			// 
			// txtNElementos
			// 
			this->txtNElementos->Location = System::Drawing::Point(468, 134);
			this->txtNElementos->Name = L"txtNElementos";
			this->txtNElementos->Size = System::Drawing::Size(100, 26);
			this->txtNElementos->TabIndex = 5;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(9, 20);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(606, 328);
			this->Controls->Add(this->txtNElementos);
			this->Controls->Add(this->lblNElementos);
			this->Controls->Add(this->dataGridView1);
			this->Controls->Add(this->btnApilar);
			this->Controls->Add(this->txtValor);
			this->Controls->Add(this->lblValor);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnApilar_Click(System::Object^  sender, System::EventArgs^  e) {
				 int val,dato;
				

				 val=System::Convert::ToInt32(txtValor-> Text);
			 //  pila1.apilar(val);        --> si apliar fuera void ahi muere sino:
				 if(pila1.apilar(val)){
				   
				     dataGridView1->ColumnCount=1;
					 dataGridView1->RowCount=pila1.gettope()+1;
					 for(int i=0; i<pila1.gettope()+1; i++){
					 
					    dato= pila1.mostrarvalor(i);
					    dataGridView1->Rows[i]->Cells[0]->Value=System::Convert::ToInt32(dato);
					    }
					 aux++;
				    txtNElementos-> Text= System::Convert::ToString(aux);
				  }
				 
				 
			 }
};
}

