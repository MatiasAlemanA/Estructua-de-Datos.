//Realizar un procedimiento que cuente la cantidad de elementos de una PILA.
//La estructura debe quedar en el estado original. 
#pragma once
#define MAX 100
class Pila
{
private: 
	int tope;
	int PILA[MAX];
		
public:
	Pila(void);
	virtual ~Pila(void);
	void iniciar();
	int gettope();
	bool pilallena();
	bool pilavacia();
	bool apilar(int dato);
	int valortope();
	int mostrarvalor(int i);
};

