#pragma once
#include "Pila.h"
#include <msclr\marshal_cppstd.h>
#include <iostream>


namespace PilaForm {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr::interop;
	Pila pilita;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  lblValor;
	private: System::Windows::Forms::TextBox^  txtValor;
	private: System::Windows::Forms::Button^  btnApilar;
	private: System::Windows::Forms::Button^  btnDesapilar;
	private: System::Windows::Forms::DataGridView^  grillaValor;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	protected: 

	protected: 





	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->lblValor = (gcnew System::Windows::Forms::Label());
			this->txtValor = (gcnew System::Windows::Forms::TextBox());
			this->btnApilar = (gcnew System::Windows::Forms::Button());
			this->btnDesapilar = (gcnew System::Windows::Forms::Button());
			this->grillaValor = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grillaValor))->BeginInit();
			this->SuspendLayout();
			// 
			// lblValor
			// 
			this->lblValor->AutoSize = true;
			this->lblValor->Location = System::Drawing::Point(12, 38);
			this->lblValor->Name = L"lblValor";
			this->lblValor->Size = System::Drawing::Size(46, 20);
			this->lblValor->TabIndex = 1;
			this->lblValor->Text = L"Valor";
			// 
			// txtValor
			// 
			this->txtValor->Location = System::Drawing::Point(95, 38);
			this->txtValor->Name = L"txtValor";
			this->txtValor->Size = System::Drawing::Size(141, 26);
			this->txtValor->TabIndex = 3;
			// 
			// btnApilar
			// 
			this->btnApilar->Location = System::Drawing::Point(257, 35);
			this->btnApilar->Name = L"btnApilar";
			this->btnApilar->Size = System::Drawing::Size(124, 33);
			this->btnApilar->TabIndex = 5;
			this->btnApilar->Text = L"Apilar";
			this->btnApilar->UseVisualStyleBackColor = true;
			this->btnApilar->Click += gcnew System::EventHandler(this, &Form1::btnApilar_Click);
			// 
			// btnDesapilar
			// 
			this->btnDesapilar->Location = System::Drawing::Point(257, 84);
			this->btnDesapilar->Name = L"btnDesapilar";
			this->btnDesapilar->Size = System::Drawing::Size(124, 32);
			this->btnDesapilar->TabIndex = 6;
			this->btnDesapilar->Text = L"Desapilar";
			this->btnDesapilar->UseVisualStyleBackColor = true;
			this->btnDesapilar->Click += gcnew System::EventHandler(this, &Form1::btnDesapilar_Click);
			// 
			// grillaValor
			// 
			this->grillaValor->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grillaValor->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->grillaValor->Location = System::Drawing::Point(27, 122);
			this->grillaValor->Name = L"grillaValor";
			this->grillaValor->RowTemplate->Height = 28;
			this->grillaValor->Size = System::Drawing::Size(389, 198);
			this->grillaValor->TabIndex = 7;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Valores";
			this->Column1->Name = L"Column1";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(9, 20);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(425, 336);
			this->Controls->Add(this->grillaValor);
			this->Controls->Add(this->btnDesapilar);
			this->Controls->Add(this->btnApilar);
			this->Controls->Add(this->txtValor);
			this->Controls->Add(this->lblValor);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grillaValor))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnApilar_Click(System::Object^  sender, System::EventArgs^  e) {
			 int aux,dato;
			 aux=System::Convert::ToInt32(txtValor->Text);
			 if(pilita.Apilar(aux))
			 {grillaValor->ColumnCount=1;
			  grillaValor->RowCount=pilita.Get_tope()+1;
			  for (int i=0;i<pilita.Get_tope()+1;i++)
				{
                dato=pilita.Get_Pila(i);
				grillaValor->Rows[i]->Cells[0]->Value=System::Convert::ToInt32(dato);
				}

			 }

			 }
private: System::Void btnDesapilar_Click(System::Object^  sender, System::EventArgs^  e) {
			int dato;
			 if(pilita.Desapilar())
			 {grillaValor->ColumnCount=1;
			  if(pilita.Get_tope()==-1)
			  {
				  grillaValor->RowCount=1;}
			  else
			  {grillaValor->RowCount=pilita.Get_tope()+1;}
			  for(int i=0;i<pilita.Get_tope()+1;i++)
			  {dato=pilita.Get_Pila(i);
			   grillaValor->Rows[i]->Cells[0]->Value=System::Convert::ToInt32(dato);
			  }
			 }

		 }
};
}

