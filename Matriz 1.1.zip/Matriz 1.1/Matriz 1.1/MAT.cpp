#include "StdAfx.h"
#include "MAT.h"



MAT::MAT(void)
{
	filas=0;
	columnas=0;
}
int MAT::GetFilas(){
return filas;}
void MAT::SetFilas(int F){
filas=F;}
int MAT::GetColumnas(){
return columnas;}
void MAT::SetColumnas(int C){
columnas=C;}
string MAT::GetMatriz(int CF, int CC){
return Matriz[CF][CC];}
void MAT::SetMatriz(int CF, int CC, string a){
Matriz[CF][CC]=a;
}
