#pragma once
#define M 50
#include "string"

using namespace std;
class MAT
{
private:
	string Matriz[M][M];
	int filas;
	int columnas;

public:
	MAT(void);
	int GetFilas();
	void SetFilas(int F);
	int GetColumnas();
	void SetColumnas(int C);
	string GetMatriz(int CF, int CC);
	void SetMatriz(int CF, int CC, string a);
	void EliminarRep();

};
