#pragma once
#include "MAT.h"
#include "string"
#include "msclr\marshal_cppstd.h"

namespace Matriz11 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr::interop;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	MAT M1;
	int posF=0;
	int posC=0;

	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  lblCF;
	protected: 
	private: System::Windows::Forms::Label^  lblCC;
	private: System::Windows::Forms::TextBox^  txtFilas;
	private: System::Windows::Forms::TextBox^  txtColumnas;
	private: System::Windows::Forms::Button^  btnDefinir;
	private: System::Windows::Forms::DataGridView^  Grid;
	private: System::Windows::Forms::Label^  lblDato;
	private: System::Windows::Forms::TextBox^  txtDato;
	private: System::Windows::Forms::Button^  btnIngresar;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->lblCF = (gcnew System::Windows::Forms::Label());
			this->lblCC = (gcnew System::Windows::Forms::Label());
			this->txtFilas = (gcnew System::Windows::Forms::TextBox());
			this->txtColumnas = (gcnew System::Windows::Forms::TextBox());
			this->btnDefinir = (gcnew System::Windows::Forms::Button());
			this->Grid = (gcnew System::Windows::Forms::DataGridView());
			this->lblDato = (gcnew System::Windows::Forms::Label());
			this->txtDato = (gcnew System::Windows::Forms::TextBox());
			this->btnIngresar = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->BeginInit();
			this->SuspendLayout();
			// 
			// lblCF
			// 
			this->lblCF->AutoSize = true;
			this->lblCF->Location = System::Drawing::Point(42, 30);
			this->lblCF->Name = L"lblCF";
			this->lblCF->Size = System::Drawing::Size(109, 20);
			this->lblCF->TabIndex = 0;
			this->lblCF->Text = L"Cantidas Filas";
			// 
			// lblCC
			// 
			this->lblCC->AutoSize = true;
			this->lblCC->Location = System::Drawing::Point(25, 86);
			this->lblCC->Name = L"lblCC";
			this->lblCC->Size = System::Drawing::Size(148, 20);
			this->lblCC->TabIndex = 1;
			this->lblCC->Text = L"Cantidad Columnas";
			this->lblCC->Click += gcnew System::EventHandler(this, &Form1::lblCC_Click);
			// 
			// txtFilas
			// 
			this->txtFilas->Location = System::Drawing::Point(221, 30);
			this->txtFilas->Name = L"txtFilas";
			this->txtFilas->Size = System::Drawing::Size(83, 26);
			this->txtFilas->TabIndex = 2;
			// 
			// txtColumnas
			// 
			this->txtColumnas->Location = System::Drawing::Point(222, 83);
			this->txtColumnas->Name = L"txtColumnas";
			this->txtColumnas->Size = System::Drawing::Size(82, 26);
			this->txtColumnas->TabIndex = 3;
			// 
			// btnDefinir
			// 
			this->btnDefinir->Location = System::Drawing::Point(373, 30);
			this->btnDefinir->Name = L"btnDefinir";
			this->btnDefinir->Size = System::Drawing::Size(76, 34);
			this->btnDefinir->TabIndex = 4;
			this->btnDefinir->Text = L"Definir";
			this->btnDefinir->UseVisualStyleBackColor = true;
			this->btnDefinir->Click += gcnew System::EventHandler(this, &Form1::btnDefinir_Click);
			// 
			// Grid
			// 
			this->Grid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid->Location = System::Drawing::Point(125, 215);
			this->Grid->Name = L"Grid";
			this->Grid->RowTemplate->Height = 28;
			this->Grid->Size = System::Drawing::Size(324, 207);
			this->Grid->TabIndex = 5;
			// 
			// lblDato
			// 
			this->lblDato->AutoSize = true;
			this->lblDato->Location = System::Drawing::Point(64, 164);
			this->lblDato->Name = L"lblDato";
			this->lblDato->Size = System::Drawing::Size(44, 20);
			this->lblDato->TabIndex = 6;
			this->lblDato->Text = L"Dato";
			// 
			// txtDato
			// 
			this->txtDato->Location = System::Drawing::Point(178, 164);
			this->txtDato->Name = L"txtDato";
			this->txtDato->Size = System::Drawing::Size(83, 26);
			this->txtDato->TabIndex = 7;
			// 
			// btnIngresar
			// 
			this->btnIngresar->Location = System::Drawing::Point(352, 158);
			this->btnIngresar->Name = L"btnIngresar";
			this->btnIngresar->Size = System::Drawing::Size(82, 39);
			this->btnIngresar->TabIndex = 8;
			this->btnIngresar->Text = L"Ingresar";
			this->btnIngresar->UseVisualStyleBackColor = true;
			this->btnIngresar->Click += gcnew System::EventHandler(this, &Form1::btnIngresar_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(9, 20);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(683, 434);
			this->Controls->Add(this->btnIngresar);
			this->Controls->Add(this->txtDato);
			this->Controls->Add(this->lblDato);
			this->Controls->Add(this->Grid);
			this->Controls->Add(this->btnDefinir);
			this->Controls->Add(this->txtColumnas);
			this->Controls->Add(this->txtFilas);
			this->Controls->Add(this->lblCC);
			this->Controls->Add(this->lblCF);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void lblCC_Click(System::Object^  sender, System::EventArgs^  e) {
			 }
private: System::Void btnDefinir_Click(System::Object^  sender, System::EventArgs^  e) {
		  int F=Convert::ToInt32(txtFilas->Text);
		  int C=Convert::ToInt32(txtColumnas->Text);
		   M1.SetFilas(F);
		   M1.SetColumnas(C);
		   Grid->RowCount=M1.GetFilas();
		   Grid->ColumnCount=M1.GetColumnas();
		 
		 }
private: System::Void btnIngresar_Click(System::Object^  sender, System::EventArgs^  e) {
			  string a=(marshal_as<std::string>(System::Convert::ToString(txtDato->Text)));
			  M1.SetMatriz(posF,posC,a);
			  Grid->Rows[posF]->Cells[posC]->Value=marshal_as<System::String^>(M1.GetMatriz(posF,posC));
		      if(posC==M1.GetColumnas()-1)
			{
				posC=0;
				posF++;
			}
			else
				posC++;	
		 
		 }
};
}

