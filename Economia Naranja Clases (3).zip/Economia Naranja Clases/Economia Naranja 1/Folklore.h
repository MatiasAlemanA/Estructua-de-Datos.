#pragma once
#include <iostream>
#include <string>
#include <msclr\marshal_cppstd.h>
using namespace std;
using namespace msclr::interop;

class Folklore
{ int numeroBaile;
int nombreBaile;
string departamento;
public:
	Folklore(void);
	virtual ~Folklore(void);
	void getnumeroBaile();
	void setnumeroBaile();

	void getnombreBaile();
	void setnombreBaile();
	
	string getdepartamento();



};

