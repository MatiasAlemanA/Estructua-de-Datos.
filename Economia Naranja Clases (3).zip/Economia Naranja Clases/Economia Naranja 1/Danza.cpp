#include "StdAfx.h"
#include "Danza.h"


Danza::Danza(void)
{
}


Danza::~Danza(void)
{
}
