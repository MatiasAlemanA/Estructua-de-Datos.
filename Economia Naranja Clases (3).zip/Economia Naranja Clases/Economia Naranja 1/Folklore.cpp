#include "StdAfx.h"
#include "Folklore.h"


Folklore::Folklore(void)
{
}


Folklore::~Folklore(void)
{
}
