#pragma once

namespace EconomiaNaranja1 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  lblFolklore;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::Button^  button4;
	private: System::Windows::Forms::Button^  button5;
	private: System::Windows::Forms::Button^  button6;
	private: System::Windows::Forms::Button^  button7;
	private: System::Windows::Forms::Button^  button8;
	private: System::Windows::Forms::Button^  button9;
	private: System::Windows::Forms::DataGridView^  dataGridView1;
	private: System::Windows::Forms::TextBox^  txtnomDep;
	private: System::Windows::Forms::TextBox^  txtnumDep;
	private: System::Windows::Forms::Label^  lblnomDep;
	private: System::Windows::Forms::Label^  lblnumDep;
	private: System::Windows::Forms::DataGridView^  dataGridView2;
	protected: 

	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->lblFolklore = (gcnew System::Windows::Forms::Label());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->button7 = (gcnew System::Windows::Forms::Button());
			this->button8 = (gcnew System::Windows::Forms::Button());
			this->button9 = (gcnew System::Windows::Forms::Button());
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->txtnomDep = (gcnew System::Windows::Forms::TextBox());
			this->txtnumDep = (gcnew System::Windows::Forms::TextBox());
			this->lblnomDep = (gcnew System::Windows::Forms::Label());
			this->lblnumDep = (gcnew System::Windows::Forms::Label());
			this->dataGridView2 = (gcnew System::Windows::Forms::DataGridView());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView2))->BeginInit();
			this->SuspendLayout();
			// 
			// lblFolklore
			// 
			this->lblFolklore->AutoSize = true;
			this->lblFolklore->Location = System::Drawing::Point(400, 23);
			this->lblFolklore->Name = L"lblFolklore";
			this->lblFolklore->Size = System::Drawing::Size(90, 13);
			this->lblFolklore->TabIndex = 0;
			this->lblFolklore->Text = L"Folklore Boliviano";
			this->lblFolklore->Click += gcnew System::EventHandler(this, &Form1::label1_Click);
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(82, 131);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(120, 41);
			this->button1->TabIndex = 1;
			this->button1->Text = L"Santa Cruz";
			this->button1->UseVisualStyleBackColor = true;
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(82, 206);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(120, 46);
			this->button2->TabIndex = 2;
			this->button2->Text = L"La Paz";
			this->button2->UseVisualStyleBackColor = true;
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(82, 288);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(120, 50);
			this->button3->TabIndex = 3;
			this->button3->Text = L"Cochabamba";
			this->button3->UseVisualStyleBackColor = true;
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(397, 131);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(93, 38);
			this->button4->TabIndex = 4;
			this->button4->Text = L"Pando";
			this->button4->UseVisualStyleBackColor = true;
			// 
			// button5
			// 
			this->button5->Location = System::Drawing::Point(397, 206);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(93, 34);
			this->button5->TabIndex = 5;
			this->button5->Text = L"Tarija";
			this->button5->UseVisualStyleBackColor = true;
			// 
			// button6
			// 
			this->button6->Location = System::Drawing::Point(397, 297);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(93, 33);
			this->button6->TabIndex = 6;
			this->button6->Text = L"Beni";
			this->button6->UseVisualStyleBackColor = true;
			// 
			// button7
			// 
			this->button7->Location = System::Drawing::Point(653, 131);
			this->button7->Name = L"button7";
			this->button7->Size = System::Drawing::Size(100, 42);
			this->button7->TabIndex = 7;
			this->button7->Text = L"Chuquisaca";
			this->button7->UseVisualStyleBackColor = true;
			// 
			// button8
			// 
			this->button8->Location = System::Drawing::Point(653, 202);
			this->button8->Name = L"button8";
			this->button8->Size = System::Drawing::Size(100, 43);
			this->button8->TabIndex = 8;
			this->button8->Text = L"Oruro";
			this->button8->UseVisualStyleBackColor = true;
			// 
			// button9
			// 
			this->button9->Location = System::Drawing::Point(653, 293);
			this->button9->Name = L"button9";
			this->button9->Size = System::Drawing::Size(100, 41);
			this->button9->TabIndex = 9;
			this->button9->Text = L"Potosi";
			this->button9->UseVisualStyleBackColor = true;
			// 
			// dataGridView1
			// 
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView1->Location = System::Drawing::Point(229, 385);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->Size = System::Drawing::Size(465, 230);
			this->dataGridView1->TabIndex = 10;
			// 
			// txtnomDep
			// 
			this->txtnomDep->Location = System::Drawing::Point(181, 58);
			this->txtnomDep->Name = L"txtnomDep";
			this->txtnomDep->Size = System::Drawing::Size(100, 20);
			this->txtnomDep->TabIndex = 11;
			// 
			// txtnumDep
			// 
			this->txtnumDep->Location = System::Drawing::Point(181, 84);
			this->txtnumDep->Name = L"txtnumDep";
			this->txtnumDep->Size = System::Drawing::Size(100, 20);
			this->txtnumDep->TabIndex = 13;
			// 
			// lblnomDep
			// 
			this->lblnomDep->AutoSize = true;
			this->lblnomDep->Location = System::Drawing::Point(61, 61);
			this->lblnomDep->Name = L"lblnomDep";
			this->lblnomDep->Size = System::Drawing::Size(114, 13);
			this->lblnomDep->TabIndex = 14;
			this->lblnomDep->Text = L"Nombre Departamento";
			// 
			// lblnumDep
			// 
			this->lblnumDep->AutoSize = true;
			this->lblnumDep->Location = System::Drawing::Point(61, 87);
			this->lblnumDep->Name = L"lblnumDep";
			this->lblnumDep->Size = System::Drawing::Size(114, 13);
			this->lblnumDep->TabIndex = 15;
			this->lblnumDep->Text = L"Numero Departamento";
			// 
			// dataGridView2
			// 
			this->dataGridView2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView2->Location = System::Drawing::Point(363, 58);
			this->dataGridView2->Name = L"dataGridView2";
			this->dataGridView2->Size = System::Drawing::Size(331, 59);
			this->dataGridView2->TabIndex = 16;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(950, 627);
			this->Controls->Add(this->dataGridView2);
			this->Controls->Add(this->lblnumDep);
			this->Controls->Add(this->lblnomDep);
			this->Controls->Add(this->txtnumDep);
			this->Controls->Add(this->txtnomDep);
			this->Controls->Add(this->dataGridView1);
			this->Controls->Add(this->button9);
			this->Controls->Add(this->button8);
			this->Controls->Add(this->button7);
			this->Controls->Add(this->button6);
			this->Controls->Add(this->button5);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->lblFolklore);
			this->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView2))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void label1_Click(System::Object^  sender, System::EventArgs^  e) {
			 }
	};
}

