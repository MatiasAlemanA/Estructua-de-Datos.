#pragma once
 class Departamentos
{
private:
	string nombredep;
	int numdep;
public:
	Departamentos(void);
	virtual ~Departamentos(void);
	void Get_nombredep();
	void Get_numdep();
	void Set_nombredep();
	void Set_numdep();
};

