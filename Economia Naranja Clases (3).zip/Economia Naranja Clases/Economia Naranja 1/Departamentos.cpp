#include "StdAfx.h"
#include "Departamentos.h"


Departamentos::Departamentos(void)
{
}


Departamentos::~Departamentos(void)
{
}
