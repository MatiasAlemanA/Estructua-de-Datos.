#pragma once
#include <iostream>
#include <string>
#include<msclr\marshal_cppstd.h>
#include "Folklore.h"

using namespace std;
using namespace msclr::interop;
const int NC=20;
class Danza
{
	int frente;
	int final;

public:
	Danza(void);
	virtual ~Danza(void);
	bool Cola_vacia();
	bool Cola_llena();
	bool Insertar(danza);
	bool Eliminar(danza);
	int  Get_frente();

	Danza This_cola();
	void This_cola(Danza);
};

