#include "StdAfx.h"
#include "Pila.h"
#include <iostream>
#define MAX 5
using namespace std;

Pila::Pila(void)
{ 
  Tope=-1;
}


Pila::~Pila(void)
{
}
int Pila::Get_tope()
{
	return Tope;
}
int Pila::Get_Pila(int posicion)
{
	return pila[posicion];
}
bool Pila::PilaVacia()
{if(Get_tope()==-1)
{return true;
}else{return false;}
}
bool Pila::pilallena()
{if(Get_tope()==(MAX-1))
 {return true;
 }
 else{return false;}
}
bool Pila::Apilar(int elemento)
{
  if(pilallena())
  {
  return false; 
  }
  else
  {Tope=Get_tope()+1;
  pila[Get_tope()]=elemento;
  return true;
  }
}
void Pila::ordenar()
{int aux;
 for(int i=0;i<(Get_tope()/2);i++)
 {for(int j=Get_tope(); j>(Get_tope()/2);j--)
  {aux=pila[i];
   pila[i]=pila[j];
   pila[j]=aux;
  }
 }
}


