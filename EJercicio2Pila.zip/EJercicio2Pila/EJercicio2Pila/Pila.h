#pragma once
#define MAX 5
class Pila
{private:
 int pila[MAX];
 int Tope;
public:
	Pila(void);
	~Pila(void);
	int Get_Pila(int posicion);
	int Get_tope();
	bool Apilar(int elemento);
	bool PilaVacia();
	bool pilallena();
	void ordenar();
};

