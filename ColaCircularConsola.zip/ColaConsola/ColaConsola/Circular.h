#pragma once
#define TAM 6
class Circular
{private:
 int v[TAM];
 int cabeza;
 int final;

 public:
	Circular(void);
	~Circular(void);
	void Insertar(int elem);
	int Eliminar();
	void Mostrar();
};

