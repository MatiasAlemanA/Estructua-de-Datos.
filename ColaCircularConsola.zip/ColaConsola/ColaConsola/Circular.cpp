#include "StdAfx.h"
#include "Circular.h"
#include <iostream>
#include "conio.h"

#define TAM 6

using namespace std;

Circular::Circular(void)
{
 cabeza=0;
 final=0;
}
Circular::~Circular(void)
{
}

void Circular::Insertar(int elem)
{if ( ((final == TAM) && cabeza == 1)
            || cabeza == final + 1 )
 {
        cout << "La cola esta llena." << endl;
    }
    // Caso contrario si hay campo para uno mas
    else {
        // Si llegamos al ultimo, empezamos desde cero (desde el inicio)
        if (final == TAM){ final = 1; }
        else{
            if (cabeza == 0){
                cabeza = 1;
                final = 1;
            } else {
                final ++;
            }
            v[final] = elem;
        }
    }
}
int Circular::Eliminar()
{
 if (cabeza == 0){
        cout << "La cola esta vacia." << endl;
    } else {
        if (cabeza == TAM){
            cabeza = 1;
        } else {
            if (cabeza == final ){
                cabeza = 0;
                final = 0;
            } else {
                cabeza=cabeza+1;
            }
        }
    }
    return v[cabeza];
}
void Circular::Mostrar()
{for(int i=cabeza+1
;i<TAM;i++)
{cout<<"V["<<i-1<<"]="<<v[i]<<endl;
 }
}

