// Colapractica.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "conio.h"
#include "Cola.h"
#include <iostream>
using namespace std;

void main()
{int num,opc;
Cola colita;
  do{cout<<"1.Encolar"<<endl;
    cout<<"2.Desencolar"<<endl;
    cout<<"OPCION: ";cin>>opc;
	switch(opc)
	{case 1:
	cout<<"INGRESE UN DATO: "<<endl;
	cin>>num;
	 colita.Encolar(num);
	 break;
	case 2:
		cout<<"ELIMINADO: "<<colita.Desencolar()<<endl;
		break;
	}
    }while(opc<4);
	getch();
	
	
}

