#include "StdAfx.h"
#include "Cola.h"
#include <iostream>
using namespace std;

Cola::Cola(void)
{final=0;
 frente=0;
}


Cola::~Cola(void)
{
}
bool Cola::Encolar(int n)
{if(final==MAX)
{return false;
}
else
{
v[final]=n;
final++;
return true;
}
}
int Cola::Desencolar()
{if(frente==final)
{cout<<"cola VACIA"<<endl;
}
else
{frente++;
 return v[frente-1];
}
}
