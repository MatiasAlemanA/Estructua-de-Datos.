#pragma once
#define MAX 4
class Cola
{private:
int v[MAX];
int frente,final;
public:
	Cola(void);
	~Cola(void);
	bool Encolar(int n);
	int Desencolar();
};

