// Matias Alema defensa 1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "conio.h"
#include "Vz2019114089.h"
#define MAX 100

using namespace std;

int main(){
int vec[MAX], n;
Vz2019114089 fib;
do{
cout<<"Ingrese el tamano del vector : ";
cin>>n;
}while(n<0);

fib.VectorFibonacci(vec,n);

getch();
return 0;
}

