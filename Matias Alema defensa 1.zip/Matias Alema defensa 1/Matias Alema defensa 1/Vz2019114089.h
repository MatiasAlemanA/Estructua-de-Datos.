#pragma once
class Vz2019114089
{
private: 
	int vec[100];
	int n;
public:
	Vz2019114089(void);
	virtual ~Vz2019114089(void);

	void VectorFibonacci(int vec[], int n);

};

