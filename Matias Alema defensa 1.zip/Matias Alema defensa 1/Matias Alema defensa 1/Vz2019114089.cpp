#include "StdAfx.h"
#include "Vz2019114089.h"
#include "iostream"

using namespace std;


Vz2019114089::Vz2019114089(void)
{
	vec[10]=0;
	n=0;
}


Vz2019114089::~Vz2019114089(void)
{
}

void Vz2019114089::VectorFibonacci(int vec[], int n){
	int x=1,y,z;
	cout<<1;
	for(int k=0; k<n; k++){
	y=x+k;
	cout<<y;
	}
	
}