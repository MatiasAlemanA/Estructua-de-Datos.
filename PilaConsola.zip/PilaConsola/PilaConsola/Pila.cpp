#include "StdAfx.h"
#include "Pila.h"
#include <iostream>
#define MAX 10
using namespace std;

Pila::Pila(void)
{ 
  Tope=-1;
}


Pila::~Pila(void)
{
}
int Pila::gettope()
{
	return Tope;
}
bool Pila::PilaVacia()
{if(Tope==-1)
{return true;
}else{return false;}
}
bool Pila::Desapilar()
{if(PilaVacia())
{return false;
}
else
{Tope--;
 return true;
}
}
bool Pila::pilallena(int tope)
{if(tope==(MAX-1))
 {return true;
 }
 else{return false;}
}
bool Pila::Apilar(int elemento)
{
  if(pilallena(Tope))
  {
  return false; 
  }
  else
  {Tope++;
  pila[Tope]=elemento;
  return true;
  }
}
void Pila::verpila(int pos)
{
 cout<<"Pila["<<pos<<"]:"<<pila[pos]<<endl;
 
}

